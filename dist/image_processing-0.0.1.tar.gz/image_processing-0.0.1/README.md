# image_processing

Description. 
The package image_processing is used to:
	- Este pacote fornece utilitários para tratamento de imagens.
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing

```bash
pip install image_processing
```

## Usage

```python
from image_processing.utils import plot
plot.plot_image()
```

## Author
Jorge Montero forked from tiemi

## License
[MIT](https://choosealicense.com/licenses/mit/)